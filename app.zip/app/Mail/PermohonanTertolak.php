<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PermohonanTertolak extends Mailable
{
    use Queueable, SerializesModels;

    public $permohonan;
    public $tiket;

    public function __construct($permohonan, $tiket)
    {
        $this->permohonan = $permohonan;
        $this->tiket = $tiket;
    }

    public function build()
    {
        return $this->subject('Permohonan Anda Ditolak')
                    ->view('emails.permohonan_ditolak');
    }
}

