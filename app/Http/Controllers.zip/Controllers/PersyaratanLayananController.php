<?php

namespace App\Http\Controllers;

use App\Models\PersyaratanLayanan;
use Illuminate\Http\Request;

class PersyaratanLayananController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PersyaratanLayanan $persyaratanLayanan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PersyaratanLayanan $persyaratanLayanan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, PersyaratanLayanan $persyaratanLayanan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PersyaratanLayanan $persyaratanLayanan)
    {
        //
    }
}
